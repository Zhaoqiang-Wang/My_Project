clc; clear; close all;

% Select Test Functions
funcName = 'sphere';
Dim = 30;
useCECbias = true; 
[LB,UB,dim,Fobj,prettyName] = cec2022_funcs(funcName,Dim,useCECbias);

PopSize = 30;
MaxIter = 300;

[best_pos,best_fit,curve] = MAHSBOA(PopSize,dim,MaxIter,LB,UB,Fobj);

semilogy(1:MaxIter,curve,'LineWidth',2);
xlabel('Iteration'); ylabel('Best fitness (log)'); grid on;
title(['MAHSBOA Convergence on ', prettyName]);

disp(['Function: ', prettyName]);
disp(['Best fitness: ', num2str(best_fit)]);
disp(['Best position (first 5 dims): ', num2str(best_pos(1:min(5,dim)))]);

