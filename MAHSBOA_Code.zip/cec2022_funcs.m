function [lb,ub,dim,fobj,name] = cec2022_funcs(funcName,Dim,useCECbias)

if nargin < 2 || isempty(Dim)
    Dim = 30;
end
if nargin < 3
    useCECbias = false;
end

switch lower(funcName)
    case {'sphere','f1'}
        name = 'Sphere';
        dim = Dim;
        lb = -100*ones(1,dim);
        ub =  100*ones(1,dim);
        if useCECbias
            bias = 300; % CEC-style bias so optimum is 300
            fobj = @(x) sum(x.^2) + bias;
            name = 'Sphere (CEC2022 biased)';
        else
            fobj = @(x) sum(x.^2);
        end
    otherwise
        error('Unsupported function name: %s', funcName);
end
end

