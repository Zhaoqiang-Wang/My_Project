%Paper: Multi-strategy secretary bird optimization algorithm for threshold segmentation of cardiac CT images
% Authors: Zhaoqiang Wang;Hao Liu;LiangPing Tu
% Journal: Applied Mathematical Modelling
% DOI:
% Coded by Hao Liu, 2025-10-14. Email: haoliu@ustl.edu.cn, liuhustl@sina.cn
function [Best_position,Best_fitness,Convergence_curve]=MAHSBOA(PopSize,Dim,MaxIter,LB,UB,Fobj)
% 

% Initialize population
X=zeros(PopSize,Dim);
for i=1:PopSize
    X(i,:)=LB+rand(1,Dim).*(UB-LB);
end

% Initial fitness and global best
Fitness=zeros(PopSize,1);
for i=1:PopSize
    Fitness(i)=Fobj(X(i,:));
end
[gbestValue,idx]=min(Fitness);
Gbest=X(idx,:);


FEs=PopSize;                     % initial evaluations done for the first population
MaxFEsApprox=PopSize*MaxIter;    % approximate max evaluations for progress scaling

Convergence_curve=zeros(1,MaxIter);

for t=1:MaxIter
    % Predation strategy (search/approach/attack)
    for i=1:PopSize
        if t<MaxIter/3
            Rn=size(X,1);
            X_random_1=randi([1,Rn]);
            X_random_2=randi([1,Rn]);
            R1=rand(1,Dim);
            X1=X(i,:)+(X(X_random_1,:)-X(X_random_2,:)).*R1;
            X1=BoundaryCheck(X1,LB,UB,'Limit2Boundary');
        elseif t>MaxIter/3 && t<2*MaxIter/3
            RB=randn(1,Dim);
            X1=Gbest+exp((t/MaxIter)^4)*(RB-0.5).*(Gbest-X(i,:));
            X1=BoundaryCheck(X1,LB,UB,'Limit2Boundary');
        else
            if rand < 0.5
                JK = randperm(PopSize);
                beta = 1.5 + 0.5*(t/MaxIter);
                L = Levy(Dim, beta);
                F = 0.5 * (1 - t/MaxIter);
                if rand < 0.5
                    lambda = 0.1 + 0.4*rand;
                    X1 = Gbest + lambda * L .* (Gbest - X(i,:));
                else
                    X1 = X(i,:) + F * (Gbest - X(i,:)) + F * L .* (X(JK(1),:) - X(JK(2),:));
                end
            else
                tau = (sqrt(5)-1) / 2;
                theta1 = -pi + 2 * pi * (1 - tau);
                theta2 = -pi + 2 * pi * tau;
                s1 = 2 * pi * rand;
                s2 = pi * rand;
                X1 = X(i, :) * abs(sin(s1)) + s2 * abs(sin(s1)) * abs(theta1 * Gbest - theta2 * Gbest);
            end
            X1=BoundaryCheck(X1,LB,UB,'Limit2Boundary');
        end

        f_newP1=Fobj(X1);
        FEs=FEs+1; % increment evaluations
        if f_newP1<=Fitness(i)
            X(i,:)=X1;
            Fitness(i)=f_newP1;
        end

        if Fitness(i)<gbestValue
            gbestValue=Fitness(i);
            Gbest=X(i,:);
        end
    end

    % Escape strategy
    k=randperm(PopSize,1);
    Xrandom=X(k,:);
    escape_prob=0.6*(1-0.25*(t/MaxIter)^2);
    w=2;
    d1_max=0.5; d1_min=0.05;
    d1=d1_max-(d1_max-d1_min)*(t/MaxIter);

    for i=1:PopSize
        if rand < escape_prob
            if rand < 0.5
                r_val=rand(1,Dim);
                sin_term=sin(pi*(r_val-0.5));
                step =  w * sin_term * (1 - FEs/MaxFEsApprox);
                step2=0.1*w * sin_term * (1 - FEs/MaxFEsApprox);
                if rand() > d1
                    X2=X(i,:)+step .* (Gbest - X(i,:));
                else
                    X2=X(i,:)+step2.* (Gbest - X(i,:));
                end
            else
                RB=rand(1,Dim);
                X2=Gbest + (1-t/MaxIter)^2 * (2*RB-1) .* X(i,:);
            end
        else
            Cr_max=0.5; Cr_min=0.05;
            Cr=Cr_max - (Cr_max-Cr_min) * (t/MaxIter);
            if rand < Cr
                rand_partner=randi(PopSize);
                dim_to_swap=randi(Dim);
                X2=X(i,:);
                X2(dim_to_swap)=X(rand_partner,dim_to_swap);
            else
                K=round(1+rand(1,1));
                R2=rand(1,Dim);
                X2=X(i,:) + R2.*(Xrandom - K.*X(i,:));
            end
        end

        X2=BoundaryCheck(X2,LB,UB,'Limit2Boundary');
        f_newP2=Fobj(X2);
        FEs=FEs+1; % increment evaluations
        if f_newP2<=Fitness(i)
            X(i,:)=X2;
            Fitness(i)=f_newP2;
        end

        if Fitness(i)<gbestValue
            gbestValue=Fitness(i);
            Gbest=X(i,:);
        end
    end

    Convergence_curve(t)=gbestValue;
end

Best_fitness=gbestValue;
Best_position=Gbest;
end

%% 子函数
function Xi=BoundaryCheck(Xi,LB,UB,strategy)
switch strategy
    case 'Reinitialization'
        Dim=length(Xi);
        S=(Xi>UB)+(Xi<LB);
        Xi=(rand(1,Dim).*(UB-LB)+LB).*S+Xi.*(~S);
    case 'Limit2Boundary'
        Xi=min(max(Xi,LB),UB);
    case 'Reflection'
        pos = Xi < LB;
        Xi(pos) = min(2*LB(pos)-Xi(pos),UB(pos));
        pos = Xi > UB;
        Xi(pos) = max(2*UB(pos)-Xi(pos),LB(pos));
end
end

function o=Levy(d,beta)
sigma=(gamma(1+beta)*sin(pi*beta/2)/(gamma((1+beta)/2)*beta*2^((beta-1)/2)))^(1/beta);
u=randn(1,d)*sigma;
v=randn(1,d);
step=u./abs(v).^(1/beta);
o=step;
end